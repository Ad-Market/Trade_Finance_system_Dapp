For browsers which do not support web3 inherently, include the following tag:

<script type="text/javascript" src="../web3.js-develop/dist/web3.js"></script>
