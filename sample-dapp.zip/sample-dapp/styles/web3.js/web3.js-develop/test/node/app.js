var web3 = require('web3');

console.log(web3.version.api);


