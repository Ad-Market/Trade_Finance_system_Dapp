var config = {};

config.ethAddress = '0x69da22156acc1fe4a87b57f72081503183883be1';
config.registryAddress = '0x67f4354642db5405b596cccd38c66af2cd5977de';
config.web3Provider = "http://35.154.153.81:8545";
config.gasPrice = 4000000000;
config.gasUsage = 1000000;
module.exports = config;
